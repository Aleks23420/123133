<?php
// Entry point for the sport store
?>